
# Change Log
## v0.0.8
support contract method `call` and `send` with options `storageLimit`,`epochHeight`,`chainId`

## v0.0.7
`cfxtruffle exec` supports context `cfx`

## v0.0.6
1. `cfxtruffle console` supports subcommand `cfxutil`
2. `cfxtruffle console` supports auto sign transaction by configed privateKeys when `cfx.sendTransaction`
3. enhanced error handle in `cfxtruffle console`

## v0.0.5
1. Support config privateKeys for signing in local and send transaction to remote node
2. Provide more detail info when execute rpc error in `cfxtruffle console`
