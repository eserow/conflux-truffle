module.exports = {
  interval: 80,
  frames: [
    "   ⠋",
    "   ⠙",
    "   ⠹",
    "   ⠸",
    "   ⠼",
    "   ⠴",
    "   ⠦",
    "   ⠧",
    "   ⠇",
    "   ⠏"
  ]
};
