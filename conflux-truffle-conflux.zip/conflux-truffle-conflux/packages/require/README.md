# truffle-exec
Executed a Javascript module within a Truffle context
