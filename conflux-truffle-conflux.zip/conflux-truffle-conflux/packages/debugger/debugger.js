require("source-map-support/register");
var Debugger = require("./lib/debugger").default;

module.exports = Debugger;
