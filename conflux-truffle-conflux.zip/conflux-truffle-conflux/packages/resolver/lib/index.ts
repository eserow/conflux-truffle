import "source-map-support/register";

import { Resolver } from "./resolver";

export { Resolver };

module.exports = Resolver;
