# @truffle/contract-sources
Utility for finding all contracts within a directory
