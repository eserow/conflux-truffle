# @truffle/environment

Environment-related files. Use this packages to detect the environment
a project is using, and to update configuration values such as the provider or networks.
