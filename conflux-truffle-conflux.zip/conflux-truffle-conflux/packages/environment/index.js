const Environment = require("./environment");
const Develop = require("./develop");

module.exports = { Environment, Develop };
