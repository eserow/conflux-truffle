declare module "vcsurl" {
  export default function vcsurl(vcsurl: string): string;
}
