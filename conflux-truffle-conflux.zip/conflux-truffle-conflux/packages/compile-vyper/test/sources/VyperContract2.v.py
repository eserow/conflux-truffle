@public
@payable
def vyper_action():
    pass
