# @truffle/error
Simple module that allows native Error objects to be extended
